#!/bin/bash

# Update and install dependencies
sudo apt-get update
sudo apt-get install -y ca-certificates curl

# Create keyring directory with correct permissions
sudo install -m 0755 -d /etc/apt/keyrings

# Download Docker's GPG key and set permissions
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

# Add Docker's official repository
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] \
https://download.docker.com/linux/ubuntu \
$(. /etc/os-release && echo "${UBUNTU_CODENAME:-$VERSION_CODENAME}") stable" | \
sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Update apt sources
sudo apt-get update
