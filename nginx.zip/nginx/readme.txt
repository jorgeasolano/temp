
---

### **1️⃣ `max_fails=2` → Número de Fallos Permitidos**
- Esto significa que **Nginx intentará enviar una solicitud al servidor (`web1` o `web2`)**.
- Si el servidor **falla dos veces seguidas**, Nginx lo marca como **"caído"** y deja de enviarle tráfico temporalmente.
- Un "fallo" puede ser:
  - El servidor **no responde**.
  - El servidor devuelve **errores** como **500, 502, 503 o 504**.
  - La conexión **tarda demasiado en responder** (timeout).

---

### **2️⃣ `fail_timeout=10s` → Tiempo que el Servidor se Considera "Caído"**
- Después de **2 fallos consecutivos**, el servidor se pone en "pausa" por **10 segundos**.
- Durante este tiempo, **Nginx NO enviará más solicitudes a ese servidor**.
- Después de **10 segundos**, Nginx **prueba nuevamente el servidor** para ver si está disponible.
- Si el servidor **responde correctamente**, vuelve a recibir tráfico.
- Si el servidor **sigue caído**, Nginx esperará otros **10 segundos** antes de intentarlo de nuevo.

---

### **Ejemplo Práctico**
- Tienes **2 servidores**:  
  ✅ `web1:3001`  
  ✅ `web2:3001`
- Nginx envía solicitudes a `web1` primero.
- `web1` **falla 2 veces seguidas** (no responde o devuelve errores).
- Nginx **deja de enviar tráfico a `web1` durante 10 segundos**.
- Mientras tanto, **todas las solicitudes van a `web2`**.
- Después de **10 segundos**, Nginx prueba `web1` otra vez:
  - Si `web1` **funciona**, vuelve a recibir tráfico.
  - Si `web1` **sigue caído**, Nginx espera otros **10 segundos** antes de volver a probar.

---

### **¿Qué Pasa si No Configuras Esto?**
🚫 Si **NO usas `max_fails` y `fail_timeout`**, Nginx puede seguir enviando tráfico a un servidor **caído**, lo que hará que el sitio web se vuelva lento o deje de responder.  

✅ Con estos ajustes, **Nginx detecta más rápido los fallos y envía el tráfico a un servidor funcional**, garantizando una mejor disponibilidad.  

🔹 **¿Quieres una detección aún más rápida?** Usa:  
```nginx
max_fails=1 fail_timeout=5s;
```
Esto hará que **el cambio de servidor sea casi inmediato**. 🚀